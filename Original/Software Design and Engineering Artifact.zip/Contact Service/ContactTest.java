//============================================================================
// Name        : ContactTest.java
// Author      : Brigitte McColl
// Description : Testing the creation of the contacts from Contact.java
//					test if the values are null or not following their specific requirements
//============================================================================

package com.brigittemccoll;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactTest {
	
	private Contact contact = new Contact("FirstName", "LastName","1234567891","Address");

	@Test
	@DisplayName("ContactID can not have more than 10 characters")
	void testContact() {
		Contact contact = new Contact("FirstName", "LastName","1234567891","Address");
		if(contact.getContactID().length() > 10) {
			fail("ContactID has more than 10 characters");
		}
	}
	
	@Test
	@DisplayName("First Name can not be more than 10 characters")
	void testFirstName() {
		Contact contact = new Contact("BrigitteMcColl", "LastName","1234567891","Address");
		if(contact.getFirstName().length() > 10) {
			fail("First Name has more than 10 characters");
		}
	}
	
	@Test
	@DisplayName("Last Name can not be more than 10 characters")
	void testLastName() {
		Contact contact = new Contact("FirstName", "BrigitteMcColl","1234567891","Address");
		if(contact.getLastName().length() > 10) {
			fail("Last Name has more than 10 characters");
		}
	}
	
	@Test
	@DisplayName("Phone Number has to be 10 characters")
	void testPhoneNumber() {
		Contact contact = new Contact("FirstName", "LastName","4444444","Address");
		if(contact.getPhoneNumber().length() != 10) {
			fail("Phone Number does not have 10 characters");
		}
	}
	
	@Test
	@DisplayName("Address can not be more than 30 characters")
	void testAddress() {
		Contact contact = new Contact("FirstName", "LastName","1234567891","Can your address can be super long");
		if(contact.getAddress().length() > 30) {
			fail("Address has more than 30 characters");
		}
	}
	
	@Test
	@DisplayName("Setting FirstName is not successful")
	void testSetFirstName()
	{
		String invalidFirstName = "BrigitteMcColl";
		//asserting first name is longer than 10 characters so exception is thrown
		assertThrows(IllegalArgumentException.class, () -> contact.setFirstName(invalidFirstName));
	}
	
	@Test
	@DisplayName("Setting LastName is not successful")
	void testSetLastName()
	{
		String invalidLastName = "BrigitteMcColl";

		//asserting last name is longer than 10 characters so exception is thrown
		assertThrows(IllegalArgumentException.class, () -> contact.setLastName(invalidLastName));
	}

	@Test
	@DisplayName("Setting PhoneNumber is not successful")
	void testSetPhoneNumber()
	{
		String invalidPhoneNumber = "4444444";

		//asserting last name is longer than 10 characters so exception is thrown
		assertThrows(IllegalArgumentException.class, () -> contact.setPhoneNumber(invalidPhoneNumber));
	}

	@Test
	@DisplayName("Setting Address is not successful")
	void testSetAddress()
	{
		String invalidAddress = "Can your address can be super long";

		//asserting last name is longer than 10 characters so exception is thrown
		assertThrows(IllegalArgumentException.class, () -> contact.setAddress(invalidAddress));
	}
	
	@Test
	@DisplayName("First Name can not be null")
	void testFirstNameNull()
	{
		Contact contact = new Contact(null, "LastName","1234567891","Address");
		assertNotNull(contact.getFirstName(), "First Name is null");
	}
	@Test
	@DisplayName("Last Name can not be null")
	void testLastNameNull()
	{
		Contact contact = new Contact("FirstName", null ,"1234567891","Address");
		assertNotNull(contact.getLastName(), "Last Name is null");
	}

	@Test
	@DisplayName("Phone Number can not be null")
	void testPhoneNumberNull()
	{
		Contact contact = new Contact("FirstName", "LastName", null ,"Address");
		assertNotNull(contact.getPhoneNumber(), "First Name is null");
	}
	
	@Test
	@DisplayName("Address can not be null")
	void testAdressNull()
	{
		Contact contact = new Contact("FirstName", "LastName","1234567891", null);
		assertNotNull(contact.getAddress(), "First Name is null");
	}

}
