//============================================================================
// Name        : ContactServiceTest.java
// Author      : Brigitte McColl
// Description : Testing Methods created in ContactService.java to confirm they
//					are working properly
//============================================================================

package com.brigittemccoll;


import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;


import java.util.ArrayList;

public class ContactServiceTest {

	@Test
	@DisplayName("Adding a new Contact")
	void testAddContact()
	{
		//create new contact
		ContactService service = new ContactService();
		service.addContact("Jane", "Doe", "5555555555", "1234 Corner Street");
		
		//assert that the contact was added properly and not null
		assertNotNull(service.getContact("0"), "Contact was not added successfully");
	}
	
	@Test
	@DisplayName("Deleting a Contact")
	void testDeleteContact()
	{
		//create new contact
		ContactService service = new ContactService();
		service.addContact("Jane", "Doe", "5555555555", "1234 Corner Street");
		
		//delete contact
		service.deleteContact("0");
		
		//create new list to compare to empty list
		ArrayList<Contact> emptyContact = new ArrayList<Contact>();
		
		//assert that the original list equals the empty list showing the contact was deleted
		assertEquals(service.contacts, emptyContact, "Contact was not deleted successfully");
	}
	
	@Test
	@DisplayName("Updating the First Name of a contact")
	void testUpdateFirstName()
	{
		//create new contact
		ContactService service = new ContactService();
		service.addContact("Jane", "Doe", "5555555555", "1234 Corner Street");
		
		//change/update first name
		service.updateFirstName("7","Susan");
		
		//service.displayContactList();
		//assert that the original first name has been updated to the new firstname
		assertEquals("Susan", service.getContact("7").getFirstName(), "First Name was not updated successfully");
	}
	
	@Test
	@DisplayName("Updating the Last Name of a contact")
	void testUpdateLatName()
	{
		//create new contact
		ContactService service = new ContactService();
		service.addContact("Jane", "Doe", "5555555555", "1234 Corner Street");
		
		//change/update last name
		service.updateLastName("5","Smith");
		
		//service.displayContactList();
		//assert that the original last name has been updated to the new last name
		assertEquals("Smith", service.getContact("5").getLastName(), "Last Name was not updated successfully");
	}
	
	@Test
	@DisplayName("Updating the PhoneNumber of a contact")
	void testUpdatePhoneNumber()
	{
		//create new contact
		ContactService service = new ContactService();
		service.addContact("Jane", "Doe", "5555555555", "1234 Corner Street");
		
		//change/update Phone Number
		service.updatePhoneNumber("3","7777777777");
		
		//service.displayContactList();
		//assert that the original phone number has been updated to the new phone number
		assertEquals("7777777777", service.getContact("3").getPhoneNumber(), "Phone Number was not updated successfully");
	}
	
	@Test
	@DisplayName("Updating the Address of a contact")
	void testUpdateAddress()
	{
		//create new contact
		ContactService service = new ContactService();
		service.addContact("Jane", "Doe", "5555555555", "1234 Corner Street");
		
		//change/update address
		service.updateAddress("1","5678 Main Street");
		
		//service.displayContactList();
		//assert that the original address has been updated to the new address
		assertEquals("5678 Main Street", service.getContact("1").getAddress(), "Address was not updated successfully");
	}
}
