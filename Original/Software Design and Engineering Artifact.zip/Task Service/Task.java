//============================================================================
// Name        : Task.java
// Author      : Brigitte McColl
// Description : The create of the object Task to hold the task information
//============================================================================

package com.brigittemccoll;

import java.util.concurrent.atomic.AtomicLong;

public class Task {
	private final String taskID;
	String taskName;
	String taskDescription;
	private static AtomicLong idGenerator = new AtomicLong();
	
//constructor
public Task(String name, String description)
{
	//generating ID number
	this.taskID = String.valueOf(idGenerator.getAndIncrement());
	
	//checks is task name is null
	if(name == null) {
		this.taskName = "null";
	}
	//checks is task name is more than 10 characters
	else if(name.length() > 20)
	{
		this.taskName = name.substring(0, 10);
	}else {
		this.taskName = name;
	}
	
	//checks is task description is null
	if(description == null) {
		this.taskDescription = "null";
	}
	//checks is task description is more than 50 characters
	else if(description.length() > 50)
	{
		this.taskDescription = description.substring(0, 10);
	}else {
		this.taskDescription = description;
	}
}

//Getters and Setters
public String getTaskID()
{
	return taskID;
}
public String getTaskName()
{
	return taskName;
}

public void setTaskName(String name)
{
	//checking if task name is null or task name is more than 10 characters
	if(name == null || name.length() > 10) {
		throw new IllegalArgumentException("Invalid Task Name");
	}
	else {
		this.taskName = name;
		}
}
public String getTaskDescription()
{
	return taskDescription;
}

public void setTaskDescription(String description)
{
	//checking if task description is null or task description is more than 10 characters
		if(description == null || description.length() > 50) {
			throw new IllegalArgumentException("Invalid Task Description");
		}else {
			this.taskDescription = description;
		}
}

//printing task information
@Override
public String toString()
{
	return "Task [taskID=" + taskID + ", taskName=" + taskName + ", taskDescription=" + taskDescription + "]";
}
}
