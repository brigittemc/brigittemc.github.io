//============================================================================
// Name        : TaskService.java
// Author      : Brigitte McColl
// Description : Methods created to add a task, delete a task, get a task,
//					and update the tasks name and description
//============================================================================

package com.brigittemccoll;

import java.util.ArrayList;

public class TaskService {

	//list to hold all of the tasks
	public ArrayList<Task> tasks = new ArrayList<Task>();
	
	//adding a task to the task list
	public void addTask(String name, String description)
	{
		//create task
		Task task = new Task(name, description);
		//add new task to list
		tasks.add(task);
	}
	
	//Used to help find the Task ID's to test
		/*// Display the full list of contacts to the console for error checking.
			public void displayTaskList() {
				for (int counter = 0; counter < tasks.size(); counter++) {
					System.out.println("\t Task ID: " + tasks.get(counter).getTaskID());
					System.out.println("\t Task Name: " + tasks.get(counter).getTaskName());
					System.out.println("\t Task Description: " + tasks.get(counter).getTaskDescription() + "\n");
				}
			}
		*/
	
	//getting task
	public Task getTask(String ID)
	{
		//create object to hold contact
		Task task = new Task(null, null);
		
		//searches for task
		for(int i = 0; i < tasks.size(); i++)
		{
			//if task is found
			if(tasks.get(i).getTaskID().contentEquals(ID))
			{
				task = tasks.get(i);
			}
		}
		
		//return found task or null
		return task;
	}
	
	//Deleting Task
	public void deleteTask(String ID)
	{
		//searches for task
		for(int i = 0; i < tasks.size(); i++)
		{
			//if task is found delete it from list
			if(tasks.get(i).getTaskID().contentEquals(ID))
			{
				tasks.remove(i);
				break;
			}
			//if task not found
			if(i == tasks.size() - 1)
			{
				throw new IllegalArgumentException("Task not Found");
			}
		}
	}
	
	//Update Task Name
	public void updateTaskName(String ID, String name)
	{
		//searches for task
		for(int i = 0; i < tasks.size(); i++)
		{
			//if task is found delete it from list
			if(tasks.get(i).getTaskID().contentEquals(ID))
			{
				tasks.get(i).setTaskName(name);
				break;
			}
			//if task not found
			if(i == tasks.size() - 1)
			{
				throw new IllegalArgumentException("Task not Found");
			}
		}
	}
	
	//Update Task Description
	public void updateTaskDescription(String ID, String description)
	{
		//searches for task
		for(int i = 0; i < tasks.size(); i++)
		{
			//if task is found delete it from list
			if(tasks.get(i).getTaskID().contentEquals(ID))
			{
				tasks.get(i).setTaskDescription(description);
				break;
			}
			//if task not found
			if(i == tasks.size() - 1)
			{
				throw new IllegalArgumentException("Task not Found");
			}
		}
	}
}
