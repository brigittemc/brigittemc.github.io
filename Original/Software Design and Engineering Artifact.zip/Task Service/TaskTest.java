//============================================================================
// Name        : TaskTest.java
// Author      : Brigitte McColl
// Description : Testing the creation of the tasks from Task.java
//					test if the values are null or not following their specific requirements
//============================================================================

package com.brigittemccoll;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.*;

public class TaskTest {
	
	private Task task = new Task("TaskName", "TaskDescription");

	@Test
	@DisplayName("TaskID can not be more than 10 characters")
	void testTask()
	{
		Task task = new Task("TaskName", "TaskDescription");
		if(task.getTaskID().length() > 10) {
			fail("TaskID has more than 10 characters");
		}
	}
	
	@Test
	@DisplayName("TaskName can not be more than 20 characters")
	void testTaskName()
	{
		Task task = new Task("Module 4 Milestone Tasks", "TaskDecription");
		if(task.getTaskName().length() > 20)
		{
			fail("Task Name has more than 20 characters");
		}
	}
	
	@Test
	@DisplayName("TaskDescripion can not be more than 50 characters")
	void testTaskDescription()
	{
		Task task = new Task("TaskName", "Module Four Milestone Task and Task Service Classes");
		if(task.getTaskDescription().length() > 50)
		{
			fail("Task Description has more than 50 characters");
		}
	}
	
	@Test
	@DisplayName("Setting TaskName is not successful")
	void testSetTaskName()
	{
		String invalidTaskName = "Module 4 Milestone Tasks";
		
		//asserting task name is longer than 10 characters so exception is thrown
		assertThrows(IllegalArgumentException.class, () -> task.setTaskName(invalidTaskName));
	}
	
	@Test
	@DisplayName("Setting TaskDescription is not successful")
	void testSetTaskDesc()
	{
		String invalidTaskDesc = "Module Four Milestone Task and Task Service Classes";

		//asserting task description is longer than 50 characters so exception is thrown
		assertThrows(IllegalArgumentException.class, () -> task.setTaskDescription(invalidTaskDesc));
	}

	
	@Test
	@DisplayName("TaskName can not be null")
	void testTaskNameNull()
	{
		Task task = new Task(null, "TaskDescription");
		assertNotNull(task.getTaskName(), "Task Name is null");
	}
	
	@Test
	@DisplayName("TaskDescription can not be null")
	void testTaskDescriptionNull()
	{
		Task task = new Task("TaskName", null);
		assertNotNull(task.getTaskDescription(), "Task Description is null");
	}
	
}
