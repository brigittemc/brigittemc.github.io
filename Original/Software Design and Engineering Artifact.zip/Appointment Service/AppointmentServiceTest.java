//============================================================================
// Name        : AppointmentServiceTest.java
// Author      : Brigitte McColl
// Description : Testing Methods created in AppointmentService.java to confirm they
//					are working properly
//============================================================================

package com.brigittemccoll;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Date;
import org.junit.jupiter.api.*;

public class AppointmentServiceTest {

	//default valid appointment for testing
	private Date date = new Date(System.currentTimeMillis() + 3600000);
		
	@Test
	@DisplayName("Adding a new appointment")
	void testAppointAdd()
	{
		//create new Appointment and add to list
		AppointmentService service = new AppointmentService();
		service.addAppointment(date, "Description");
		
		//assert appointment was added and not null
		assertNotNull(service.getAppointment("0"), "Contact was added successfully");
	}
	
	@Test
	@DisplayName("Deleting an appointment")
	void testAppointDelete()
	{
		//create new Appointment and add to list
		AppointmentService service = new AppointmentService();
		service.addAppointment(date, "Description");
		
		//delete the appointment
		service.deleteAppointment("0");
		
		//create empty list to compare to old list
		ArrayList<Appointment> emptyAppointments = new ArrayList<Appointment>();
		
		//assert appointment was deleted correctly
		assertEquals(service.appoint, emptyAppointments, "Appointment was deleted successfully");
	}
}
