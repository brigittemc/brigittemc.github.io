//============================================================================
// Name        : AppointmentService.java
// Author      : Brigitte McColl
// Description : Methods created to add an appointment, delete an appointment, 
//					and get an appointment
//============================================================================

package com.brigittemccoll;

import java.util.ArrayList;
import java.util.Date;

public class AppointmentService {
	
	//List to hold all of the appointments
	public ArrayList<Appointment> appoint = new ArrayList<Appointment>();
	
	//adding an appointment to the list
	public void addAppointment(Date date, String description)
	{
		//create the appointment
		Appointment appointment = new Appointment(date, description);
		
		//add the new appointment to the list
		appoint.add(appointment);
	}
	
	//Deleting an appointment
	public void deleteAppointment(String ID)
	{
		//look for task
		for(int i = 0; i < appoint.size(); i++)
		{
			//if appointment is found, delete it
			if(appoint.get(i).getAppointID().contentEquals(ID))
			{
				appoint.remove(i);
				break;
			}
			
			//if appointment is not found
			if(i == appoint.size() - 1)
			{
				System.out.println("Appointment: " + ID + " not found.");
			}
		}
	}
	
	//getting Appointment
		public Appointment getAppointment(String ID)
		{
			//I don't know why creating the empty appointment was causing the test add appointment to fail
	        //create object to hold appointment
	        //Appointment appointment = new Appointment(null, null); 
			
			
			//create basic appointment to change to found appointment
			Date date = new Date(System.currentTimeMillis());
	        Appointment appointment = new Appointment(date, "test");

	        //searches for appointment
	        for(int i = 0; i < appoint.size(); i++)
	        {
	            //if appointment is found
	            if(appoint.get(i).getAppointID().contentEquals(ID))
	            {
	                appointment = appoint.get(i);
	            }
	        }

	        //return found appointment
	        return appointment;
		}
		
				
}
