//============================================================================
// Name        : AppointmentTest.java
// Author      : Brigitte McColl
// Description : Testing the creation of the appointments from Appointment.java
//					test if the values are null or not following their specific requirements
//============================================================================

package com.brigittemccoll;

import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;
import org.junit.jupiter.api.*;

public class AppointmentTest {

	//default valid appointment for testing
	private Date date = new Date(System.currentTimeMillis() + 3600000);
	private Appointment appoint = new Appointment (date, "Description");
	
	@Test
	@DisplayName("Appointment ID can not be more than 10 characters")
	void testAppointment()
	{
		//checking appointmentID length
		if(appoint.getAppointID().length() > 10)
		{
			fail("AppointmentID has more than 10 characters");
		}
	}
	
	@Test
	@DisplayName("AppointmentDate cannot be in the past")
	void testAppointDate()
	{
		//create invalid date
		Date invalidDate = new Date(System.currentTimeMillis() - 3600000);
		
		//asserting date is in the past so exception is thrown
		assertThrows(IllegalArgumentException.class, () -> appoint.setAppointDate(invalidDate));
	}
	
	@Test
	@DisplayName("AppointmentDate gets the correct input")
	void testGetAppointDate()
	{
		//asserting getting date from list is correct
		assertEquals(appoint.getAppointDate(), date, "Received appointment description successfully");
	}
	
	@Test
	@DisplayName("AppointmentDesc cannot be more than 50 characters")
	void testAppointDesc()
	{
		//create invalid description
		String invalidDesc = "This decriptions for this appointment is longer than 50 characters";
		
		//asserting date is in the past so exception is thrown
		assertThrows(IllegalArgumentException.class, () -> appoint.setAppointDesc(invalidDesc));
	}
	
	@Test
	@DisplayName("AppointmentDesc gets the correct input")
	void testGetAppointDesc()
	{
		String description = "Description";
		//asserting getting description from list is correct
		assertEquals(appoint.getAppointDesc(), description, "Received appointment description successfully");
	}
	
	@Test
	@DisplayName("AppointmentDate can not be null")
	void testAppointDateNull()
	{
		//asserting date is null so exception is thrown
		assertThrows(IllegalArgumentException.class, () -> appoint.setAppointDate(null));
	}
	
	@Test
	@DisplayName("AppointmentDesc can not be null")
	void testAppointDescNull()
	{
		//asserting date is null so exception is thrown
		assertThrows(IllegalArgumentException.class, () -> appoint.setAppointDesc(null));
	}
}
