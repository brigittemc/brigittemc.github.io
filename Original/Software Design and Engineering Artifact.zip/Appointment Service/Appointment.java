//============================================================================
// Name        : Appointment.java
// Author      : Brigitte McColl
// Description : The create of the object Appointment to hold the task information
//============================================================================

package com.brigittemccoll;

import java.util.Date;
import java.util.concurrent.atomic.AtomicLong;

public class Appointment {
	private final String appointID;
	Date appointmentDate;
	String appointDesc;
	private static AtomicLong idGenerator = new AtomicLong();
	
	//constructor
	public Appointment(Date date, String description)
	{
		//generate ID number
		this.appointID = String.valueOf(idGenerator.getAndIncrement());
		
		//checks if date is in the past or null
		if(date.before(new Date()) || date == null)
		{
			throw new IllegalArgumentException("Invalid Appointment Date");
		}else {
			this.appointmentDate = date;
		}
		
		//checks is appointment description is null or is more than 50 characters
		if(description == null || description.length() > 50) {
			throw new IllegalArgumentException("Invalid Appointment Description");
		}else {
			this.appointDesc = description;
		}
	}
	
	//Getters and Setters
	public String getAppointID()
	{
		return appointID;
	}
	
	public Date getAppointDate() {
		return appointmentDate;
	}
	
	public void setAppointDate(Date date)
	{
		//checks if date is in the past or null
		if(date == null || date.before(new Date()))
		{
			throw new IllegalArgumentException("Invalid Appointment Date");
		}else {
			this.appointmentDate = date;
		}
	}

	public String getAppointDesc()
	{
		return appointDesc;
	}
	
	public void setAppointDesc(String description)
	{
		//checks is appointment description is null or is more than 50 characters
				if(description == null || description.length() > 50) {
					throw new IllegalArgumentException("Invalid Appointment Description");
				}else {
					this.appointDesc = description;
				}
	}
	
	//printing appointment information
	@Override
	public String toString()
	{
		return "Appointment [appointID=" + appointID + ", appointmentDate=" + appointmentDate + ", appointDescription=" + appointDesc + "]";
	}
}
