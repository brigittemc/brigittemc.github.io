package com.brigittemccoll.Tasks;

//============================================================================
//Name        : TaskTest.java
//Author      : Brigitte McColl
//Description : Testing the creation of the tasks from Task.java
//					test if the values are null or not following their specific requirements
//============================================================================


import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.*;

public class TaskTest {
	
	private Task task = new Task("TaskName", "TaskDescription");

	@Test
	@DisplayName("TaskID can not be more than 10 characters")
	void testTask()
	{
		Task task = new Task("TaskName", "TaskDescription");
		assertFalse(task.getTaskID().length() > 10);
	}
	
	@Test
	@DisplayName("TaskName can not be more than 20 characters")
	void testTaskName()
	{
		Task task = new Task("Module 4 Milestone Tasks", "TaskDecription");
		assertFalse(task.getTaskName().length() > 20);
	}
	
	@Test
	@DisplayName("TaskDescripion can not be more than 50 characters")
	void testTaskDescription()
	{
		Task task = new Task("TaskName", "Module Four Milestone Task and Task Service Classes");
		assertFalse(task.getTaskDescription().length() > 50);
	}
	
	@Test
	@DisplayName("Setting TaskName is not successful")
	void testInvalidSetTaskName()
	{
		String invalidTaskName = "Module 4 Milestone Tasks";
		
		//asserting task name is longer than 10 characters so exception is thrown
		assertThrows(IllegalArgumentException.class, () -> task.setTaskName(invalidTaskName));
	}
	
	@Test
	@DisplayName("Setting TaskDescription is not successful")
	void testInvalidSetTaskDesc()
	{
		String invalidTaskDesc = "Module Four Milestone Task and Task Service Classes";

		//asserting task description is longer than 50 characters so exception is thrown
		assertThrows(IllegalArgumentException.class, () -> task.setTaskDescription(invalidTaskDesc));
	}

	@Test
	@DisplayName("Setting TaskName is successful")
	void testSetTaskName()
	{
		Task tasks = new Task("", "");
		String validTaskName = "Module 4";
		
		tasks.setTaskName("Module 4");
		
		//asserting task name is not longer than 10 characters so it is set successfully
		assertEquals(validTaskName, tasks.getTaskName(), "Task Name was updated successfully");
	
	}
	
	@Test
	@DisplayName("Setting TaskDescription is successful")
	void testSetTaskDesc()
	{
		Task tasks = new Task("", "");
		String validTaskDesc = "Module Four Milestone";
		
		tasks.setTaskDescription("Module Four Milestone");
		
		//asserting task name is not longer than 10 characters so it is set successfully
		assertEquals(validTaskDesc, tasks.getTaskDescription(), "Task Description was updated successfully");
	}

	
	
	@Test
	@DisplayName("TaskName can not be null")
	void testTaskNameNull()
	{
		Task task = new Task(null, "TaskDescription");
		assertNotNull(task.getTaskName(), "Task Name is null");
	}
	
	@Test
	@DisplayName("TaskDescription can not be null")
	void testTaskDescriptionNull()
	{
		Task task = new Task("TaskName", null);
		assertNotNull(task.getTaskDescription(), "Task Description is null");
	}
	
}
