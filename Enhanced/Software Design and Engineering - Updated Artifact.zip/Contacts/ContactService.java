package com.brigittemccoll.Contacts;

//============================================================================
//Name        : ContactService.java
//Author      : Brigitte McColl
//Description : Methods created to add a contact, delete a contact, get a contact,
//					and update the contacts first and last name, phone number, and address
//============================================================================


import java.util.ArrayList;

public class ContactService {

	//list to hold contacts
	public ArrayList<Contact> contacts = new ArrayList<Contact>();
	
	//add contact to list
	public void addContact(String firstName, String lastName, String phoneNumber, String address)
	{
		//create contact
		Contact contact = new Contact(firstName, lastName, phoneNumber, address);
		//add contact to list
		contacts.add(contact);
	}
	
//	//Used to help find the Contact ID's to test
//	// Display the full list of contacts to the console for error checking.
//		public void displayContactList() {
//			for (int counter = 0; counter < contacts.size(); counter++) {
//				System.out.println("\t Contact ID: " + contacts.get(counter).getContactID());
//				System.out.println("\t First Name: " + contacts.get(counter).getFirstName());
//				System.out.println("\t Last Name: " + contacts.get(counter).getLastName());
//				System.out.println("\t Phone Number: " + contacts.get(counter).getPhoneNumber());
//				System.out.println("\t Address: " + contacts.get(counter).getAddress() + "\n");
//			}
//		}
//	
	//Getting Contact
		public Contact getContact(String contactID)
		{
			//create to hold contact
			Contact contact = new Contact(null, null, null, null);
			//searches list for contact
			for(int i = 0; i < contacts.size(); i++)
			{
				//if contact found add to contact
				if(contacts.get(i).getContactID().contentEquals(contactID))
				{
					contact = contacts.get(i);
				}
			}
			
			//return contact found or null
			return contact;
		}
		
	
	//Deleting Contact
	public void deleteContact(String contactID)
	{
		//searches list for contact
		for(int i = 0; i < contacts.size(); i++)
		{
			//if contact found remove from list
			if(contacts.get(i).getContactID().contentEquals(contactID))
			{
				contacts.remove(i);
				break;
			}
			//if not found print not found
			if(i == contacts.size() - 1)
			{
				throw new IllegalArgumentException("Contact not Found");
			}
		}
	}
	
	public void updateFirstName(String contactID, String firstName)
	{
		//searches list for contact
				for(int i = 0; i < contacts.size(); i++)
				{
					//if contact found update first name
					if(contacts.get(i).getContactID().contentEquals(contactID))
					{
						contacts.get(i).setFirstName(firstName);
						break;
					}
					//if not found print not found
					if(i == contacts.size() - 1)
					{
						throw new IllegalArgumentException("Contact not Found");
					}
				}
	}
	
	public void updateLastName(String contactID, String lastName)
	{
		//searches list for contact
				for(int i = 0; i < contacts.size(); i++)
				{
					//if contact found update Last Name
					if(contacts.get(i).getContactID().contentEquals(contactID))
					{
						contacts.get(i).setLastName(lastName);
						break;
					}
					//if not found print not found
					if(i == contacts.size() - 1)
					{
						throw new IllegalArgumentException("Contact not Found");
					}
				}
	}
	
	public void updatePhoneNumber(String contactID, String phoneNumber)
	{
		//searches list for contact
				for(int i = 0; i < contacts.size(); i++)
				{
					//if contact found update phone number
					if(contacts.get(i).getContactID().contentEquals(contactID))
					{
						contacts.get(i).setPhoneNumber(phoneNumber);
						break;
					}
					//if not found print not found
					if(i == contacts.size() - 1)
					{
						throw new IllegalArgumentException("Contact not Found");
					}
				}
	}
	
	public void updateAddress(String contactID, String address)
	{
		//searches list for contact
				for(int i = 0; i < contacts.size(); i++)
				{
					//if contact found update address
					if(contacts.get(i).getContactID().contentEquals(contactID))
					{
						contacts.get(i).setAddress(address);
						break;
					}
					//if not found print not found
					if(i == contacts.size() - 1)
					{
						throw new IllegalArgumentException("Contact not Found");
					}
				}
	}
	
	
	
}
