package com.brigittemccoll.Contacts;

//============================================================================
//Name        : Contact.java
//Author      : Brigitte McColl
//Description : The create of the object Contact to help hold the information
//============================================================================

import java.util.concurrent.atomic.AtomicLong;

public class Contact {
	private final String contactID;
	String firstName;
	String lastName;
	String phoneNumber;
	String address;
	private static AtomicLong idGenerator = new AtomicLong();

//Constructor
public Contact(String firstName, String lastName, String phoneNumber, String address)
{
	//generating id number
	this.contactID = String.valueOf(idGenerator.getAndIncrement());
	
	//checking if first name is null
			if(firstName == null) {
				this.firstName = "null";
			}
		//checks if first name is more than 10 characters
			else if(firstName.length() > 10) {
				this.firstName = firstName.substring(0, 10);
			}
			else {
				this.firstName = firstName;
			}
	
			//checking if last name is null
			if(lastName == null) {
				this.lastName = "null";
			}
		//checks if last name is more than 10 characters
			else if(lastName.length() > 10) {
				this.lastName = lastName.substring(0, 10);
			}
			else {
				this.lastName = lastName;
			}
	
			//checking if phone number is null or not 10 characters in length
			if(phoneNumber == null || phoneNumber.length() != 10) {
				this.phoneNumber = "1234567891";
			}
			else {
				this.phoneNumber = phoneNumber;
			}
	
			//checking if address is null
			if(address == null) {
				this.address = "null";
			}
		//checks if address is more than 30 characters
			else if(address.length() > 30) {
				this.address = address.substring(0, 30);
			}
			else {
				this.address = address;
			}
}

//Getter and Setters
public String getContactID()
{
	return contactID;
}

public String getFirstName()
{
	return firstName;
}
public void setFirstName(String firstName)
{
	//checking if first name is null or first name is more than 10 characters
		if(firstName == null || firstName.length() > 10) {
			throw new IllegalArgumentException("Invalid First Name");
		}
		else {
			this.firstName = firstName;
		}
}

public String getLastName()
{
	return lastName;
}
public void setLastName(String lastName)
{
	//checking if last name is null or last name is more than 10 characters
	if(lastName == null || lastName.length() > 10) {
		throw new IllegalArgumentException("Invalid Last Name");
	}
	else {
		this.lastName = lastName;
	}

}

public String getPhoneNumber()
{
	return phoneNumber;
}
public void setPhoneNumber(String phoneNumber)
{
	//checking if phone number is null or not 10 characters in length
	if(phoneNumber == null || phoneNumber.length() != 10) {
		throw new IllegalArgumentException("Invalid phone number");
	}
	else {
		this.phoneNumber = phoneNumber;
	}
}

public String getAddress()
{
	return address;
}
public void setAddress(String address)
{
	//checking if address is null or address is more than 30 characters
	if(address == null || address.length() > 30) {
		throw new IllegalArgumentException("Invalid address");
	}
	else {
		this.address = address;
	}
}

//printing the contact information
@Override
public String toString() {
	return "Contact [contactID=" + contactID + ", firstName=" + firstName + ", lastName=" + lastName + ", phoneNumber=" + phoneNumber + ", address=" + address + "]";
}
}
