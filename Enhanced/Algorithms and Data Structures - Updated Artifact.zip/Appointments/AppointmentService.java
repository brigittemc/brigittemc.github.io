package com.brigittemccoll.Appointments;

//============================================================================
//Name        : AppointmentService.java
//Author      : Brigitte McColl
//Description : Methods created to add an appointment, delete an appointment, 
//					and get an appointment
//============================================================================


import java.util.Date;
import java.util.HashMap;


public class AppointmentService {
	
	//creating the ID numbers
		int currentID = 0;
			
		//map to hold all of the tasks
		public HashMap<String, Appointment> appointments = new HashMap<String, Appointment>();
	
	//adding an appointment to the list
	public void addAppointment(Date date, String description)
	{
		//setting key value
		String ID = Integer.toString(currentID);
		//create the appointment
		Appointment appointment = new Appointment(date, description);
		
		//add the new appointment to the list
		appointments.put(ID, appointment);
				
		//increment the ID numbers
		++currentID;
	}
	
	// Display the full list of contacts to the console for error checking.
//	public void displayAppointList() {
//		for (int counter = 0; counter < appoint.size(); counter++) {
//			System.out.println("\t Task ID: " + appoint.get(counter).getAppointID());
//			System.out.println("\t Task Name: " + appoint.get(counter).getAppointDate());
//			System.out.println("\t Task Description: " + appoint.get(counter).getAppointDesc() + "\n");
//		}
//	}
	
	//Deleting an appointment
	public void deleteAppointment(String ID)
	{
		//searches for appointment
		if(appointments.containsKey(ID)) {
			//removes appointment if found
			appointments.remove(ID);
		}else {
			//if appointment not found throw error
			throw new IllegalArgumentException("Appointment not Found");
		}
				
	}
	
	//getting Appointment
		public Appointment getAppointment(String ID)
		{
			//I don't know why creating the empty appointment was causing the test add appointment to fail
	        //create object to hold appointment
	        //Appointment appointment = new Appointment(null, null); 
			
			
			//searches for appointment
			if(appointments.containsKey(ID)) {
				//gets appointment if found
				return appointments.get(ID);
			}else {
				//if appointment not found throw error
				System.out.println("Appointment: " + ID + " not found.");
				return null;
			}
		}
		
				
}

