package com.brigittemccoll.Appointments;

//============================================================================
//Name        : AppointmentTest.java
//Author      : Brigitte McColl
//Description : Testing the creation of the appointments from Appointment.java
//					test if the values are null or not following their specific requirements
//============================================================================

import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;
import org.junit.jupiter.api.*;

public class AppointmentTest {

	//default valid appointment for testing
	private Date date = new Date(System.currentTimeMillis() + 3600000);
	private Appointment appoint = new Appointment (date, "Description");
	
	@Test
	@DisplayName("Appointment ID can not be more than 10 characters")
	void testAppointment()
	{
		//checking appointmentID length
		assertFalse(appoint.getAppointID().length() > 10);
	}
	
	@Test
	@DisplayName("AppointmentDate cannot be in the past created through constructor")
	void testAppointDate()
	{
		//create invalid date
		Date invalidDate = new Date(System.currentTimeMillis() - 5000000);
		//use constructor to create invalid appointment
		Appointment appoint = new Appointment(invalidDate, "Appointment Description");
		
		//asserting date is in the past so exception is thrown
		assertThrows(IllegalArgumentException.class, () -> appoint.getAppointDate().after(date));
	}
	
	@Test
	@DisplayName("Setting AppointmentDate is successful")
	void testSetAppointDate()
	{
		Appointment appoint = new Appointment(date,"");
		
		Date validDate = new Date(System.currentTimeMillis() + 4000000);
		
		appoint.setAppointDate(validDate);
		//asserting date is set correctly
		assertEquals(validDate, appoint.getAppointDate(), "Appointment Date updated successfully");
	}
	
	@Test
	@DisplayName("SetAppointmentDate cannot be in the past")
	void testSetAppointDateFail()
	{
		//create invalid date
		Date invalidDate = new Date(System.currentTimeMillis() - 3600000);
		
		//asserting date is in the past so exception is thrown
		assertThrows(IllegalArgumentException.class, () -> appoint.setAppointDate(invalidDate));
	}
	
	@Test
	@DisplayName("AppointmentDate gets the correct input")
	void testGetAppointDate()
	{
		//asserting getting date from list is correct
		assertEquals(appoint.getAppointDate(), date, "Received appointment description successfully");
	}
	
	@Test
	@DisplayName("SetAppointmentDesc cannot be more than 50 characters created through constructor")
	void testAppointDesc()
	{
		//use constructor to create invalid appointment
		Appointment appoint = new Appointment(date, "This decriptions for this appointment is longer than 50 characters");
		
		//asserting description is not 50 character in length
		assertFalse(appoint.getAppointDesc().length() > 50);
	}
	
	@Test
	@DisplayName("Setting AppointmentDesc is successful")
	void testSetAppointDesc()
	{
		Appointment appoint = new Appointment(date,"");
		
		String validDesc = "Description";
		
		appoint.setAppointDesc(validDesc);
		//asserting date is set correctly
		assertEquals(validDesc, appoint.getAppointDesc(), "Appointment Description updated successfully");
	}
	@Test
	@DisplayName("SetAppointmentDesc cannot be more than 50 characters")
	void testSetAppointDescFail()
	{
		//create invalid description
		String invalidDesc = "This decriptions for this appointment is longer than 50 characters";
		
		//asserting date is in the past so exception is thrown
		assertThrows(IllegalArgumentException.class, () -> appoint.setAppointDesc(invalidDesc));
	}
	
	@Test
	@DisplayName("AppointmentDesc gets the correct input")
	void testGetAppointDesc()
	{
		String description = "Description";
		//asserting getting description from list is correct
		assertEquals(appoint.getAppointDesc(), description, "Received appointment description successfully");
	}
	
	@Test
	@DisplayName("AppointmentDate can not be null")
	void testAppointDateNull()
	{
		//asserting date is null so exception is thrown
		assertThrows(IllegalArgumentException.class, () -> appoint.setAppointDate(null));
	}
	
	@Test
	@DisplayName("AppointmentDesc can not be null")
	void testAppointDescNull()
	{
		//asserting date is null so exception is thrown
		assertThrows(IllegalArgumentException.class, () -> appoint.setAppointDesc(null));
	}
}
