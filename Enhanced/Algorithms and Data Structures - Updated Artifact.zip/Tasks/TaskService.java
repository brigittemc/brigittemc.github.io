package com.brigittemccoll.Tasks;

//============================================================================
//Name        : TaskService.java
//Author      : Brigitte McColl
//Description : Methods created to add a task, delete a task, get a task,
//					and update the tasks name and description
//============================================================================

import java.util.HashMap;

public class TaskService {

	//creating the ID numbers
	int currentID = 0;
	
	//map to hold all of the tasks
	public HashMap<String, Task> tasks = new HashMap<String, Task>();
	
	//adding a task to the task list
	public void addTask(String name, String description)
	{
		//setting key value
		String ID = Integer.toString(currentID);
		//create task
		Task task = new Task(name, description);
		//add new task to map
		tasks.put(ID, task);
		
		//increment the ID numbers
		++currentID;
	}
	
	//Used to help find the Task ID's to test
//		// Display the full list of contacts to the console for error checking.
//			public void displayTaskList() {
//				for (int counter = 0; counter < tasks.size(); counter++) {
//					System.out.println("\t Task ID: " + tasks.get(counter).getTaskID());
//					System.out.println("\t Task Name: " + tasks.get(counter).getTaskName());
//					System.out.println("\t Task Description: " + tasks.get(counter).getTaskDescription() + "\n");
//				}
//			}
		
	
	//getting task
	public Task getTask(String ID)
	{
		//searches for task
		if(tasks.containsKey(ID)) {
			//returns task if found
			return tasks.get(ID);
		}else {
			//returns null if not found
			return null;
		}
	}
	
	//Deleting Task
	public void deleteTask(String ID)
	{
		//searches for task
		if(tasks.containsKey(ID)) {
			//removes task if found
			tasks.remove(ID);
		}else {
			//if task not found throw error
			throw new IllegalArgumentException("Task not Found");
		}
	}
	
	//Update Task Name
	public void updateTaskName(String ID, String name)
	{
		//searches for task
		if(tasks.containsKey(ID)) {
			//updates the name of the task if found
			tasks.get(ID).setTaskName(name);
		}else {
			//if task not found throw error
			throw new IllegalArgumentException("Task not Found");
		}
	}
	
	//Update Task Description
	public void updateTaskDescription(String ID, String description)
	{
		//searches for task
		if(tasks.containsKey(ID)) {
			//updates the name of the task if found
			tasks.get(ID).setTaskDescription(description);
		}else {
			//if task not found throw error
			throw new IllegalArgumentException("Task not Found");
		}
	}
}
