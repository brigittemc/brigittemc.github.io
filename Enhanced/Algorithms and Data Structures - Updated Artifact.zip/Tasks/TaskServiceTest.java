package com.brigittemccoll.Tasks;

//============================================================================
//Name        : TaskServiceTest.java
//Author      : Brigitte McColl
//Description : Testing Methods created in TaskService.java to confirm they
//					are working properly
//============================================================================


import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {

	@Test
	@DisplayName("Adding new Task")
	void testAddTask()
	{
		//create new Task
		TaskService service = new TaskService();
		service.addTask("Module 4 Milestone", "Task and Task Service Classes");
		
		//assert task was added correctly and not null
		assertNotNull(service.getTask("0"), "Contact was not added successfully");
	}
	
	@Test
	@DisplayName("Deleting a Task")
	void testDeleteTask()
	{
		//create new Task
		TaskService service = new TaskService();
		service.addTask("Module 4", "Task and Task Service Classes");
		
		//Delete Task
		service.deleteTask("4");
		
		//create new list to compare to old list
		ArrayList<Task> emptyTasks = new ArrayList<Task>();
		
		//service.displayTaskList();
		//assert task was added correctly and not null
		assertEquals(service.tasks, emptyTasks, "Task was deleted successfully");
	}
	
	@Test
	@DisplayName("Deleting a Task ID Not Found")
	void testDeleteTaskNotFound()
	{
		//create new Task
		TaskService service = new TaskService();
		service.addTask("Module 4 Milestone", "Task and Task Service Classes");
		
		//assert task id was not found and deleted correctly
		assertThrows(IllegalArgumentException.class, () -> service.deleteTask("100"));
	}
	
	
	@Test
	@DisplayName("Updating Task Name")
	void testUpdateTaskName()
	{
		//create new task
		TaskService service = new TaskService();
		service.addTask("Module 4", "Task and Task Service Classes");
		//service.displayTaskList();
		//update task name
		service.updateTaskName("3", "Module");
		
		//service.displayTaskList();
		//assert original task name has been updated to new task name
		assertEquals("Module", service.getTask("3").getTaskName(), "Task Name was updated successfully");
	}
	
	@Test
	@DisplayName("Updating Task Name ID Not Found")
	void testUpdateTaskNameNotFound()
	{
		//create new Task
		TaskService service = new TaskService();
		service.addTask("Module 4 Milestone", "Task and Task Service Classes");
		
		//assert task id was not found and deleted correctly
		assertThrows(IllegalArgumentException.class, () -> service.updateTaskName("9", "Module 4"));
	}
	
	@Test
	@DisplayName("Updating Task Description")
	void testUpdateTaskDescription()
	{
		//create new task
		TaskService service = new TaskService();
		service.addTask("Module 4", "Task and Task Service Classes");
		
		//update task description
		service.updateTaskDescription("5", "Task Service Classes");
		
		//service.displayTaskList();
		//assert original task name has been updated to new task name
		assertEquals("Task Service Classes", service.getTask("5").getTaskDescription(), "Task Description was updated successfully");
	}
	
	@Test
	@DisplayName("Updating Task Description ID Not Found")
	void testUpdateTaskDescNotFound()
	{
		//create new Task
		TaskService service = new TaskService();
		service.addTask("Module 4 Milestone", "Task and Task Service Classes");
		
		//assert task id was not found and updated correctly
		assertThrows(IllegalArgumentException.class, () -> service.updateTaskDescription("9", "Task Service Classes"));
	}
}
