package com.brigittemccoll.Contacts;

//============================================================================
//Name        : ContactServiceTest.java
//Author      : Brigitte McColl
//Description : Testing Methods created in ContactService.java to confirm they
//					are working properly
//============================================================================


import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;


import java.util.ArrayList;

public class ContactServiceTest {

	@Test
	@DisplayName("Adding a new Contact")
	void testAddContact()
	{
		//create new contact
		ContactService service = new ContactService();
		service.addContact("Jane", "Doe", "5555555555", "1234 Corner Street");
		
		//assert that the contact was added properly and not null
		assertNotNull(service.getContact("0"), "Contact was not added successfully");
	}
	
	@Test
	@DisplayName("Deleting a Contact")
	void testDeleteContact()
	{
		//create new contact
		ContactService service = new ContactService();
		service.addContact("Jane", "Doe", "5555555555", "1234 Corner Street");
		
		//delete contact
		service.deleteContact("1");
		
		//create new list to compare to empty list
		ArrayList<Contact> emptyContact = new ArrayList<Contact>();
		
		
		//assert that the original list equals the empty list showing the contact was deleted
		assertEquals(service.contacts, emptyContact, "Contact was deleted successfully");
	}
	
	@Test
	@DisplayName("Updating the First Name of a contact")
	void testUpdateFirstName()
	{
		//create new contact
		ContactService service = new ContactService();
		service.addContact("Jane", "Doe", "5555555555", "1234 Corner Street");
		
		//change/update first name
		service.updateFirstName("10","Susan");
		
		//service.displayContactList();
		//assert that the original first name has been updated to the new firstname
		assertEquals("Susan", service.getContact("10").getFirstName(), "First Name was updated successfully");
	}
	
	@Test
	@DisplayName("Updating the Last Name of a contact")
	void testUpdateLatName()
	{
		//create new contact
		ContactService service = new ContactService();
		service.addContact("Jane", "Doe", "5555555555", "1234 Corner Street");
		
		//change/update last name
		service.updateLastName("8","Smith");
		
		//service.displayContactList();
		//assert that the original last name has been updated to the new last name
		assertEquals("Smith", service.getContact("8").getLastName(), "Last Name was updated successfully");
	}
	
	@Test
	@DisplayName("Updating the PhoneNumber of a contact")
	void testUpdatePhoneNumber()
	{
		//create new contact
		ContactService service = new ContactService();
		service.addContact("Jane", "Doe", "5555555555", "1234 Corner Street");
		
		//change/update Phone Number
		service.updatePhoneNumber("5","7777777777");
		
		//service.displayContactList();
		//assert that the original phone number has been updated to the new phone number
		assertEquals("7777777777", service.getContact("5").getPhoneNumber(), "Phone Number was updated successfully");
	}
	
	@Test
	@DisplayName("Updating the Address of a contact")
	void testUpdateAddress()
	{
		//create new contact
		ContactService service = new ContactService();
		service.addContact("Jane", "Doe", "5555555555", "1234 Corner Street");
		
		//change/update address
		service.updateAddress("3","5678 Main Street");
		
		//service.displayContactList();
		//assert that the original address has been updated to the new address
		assertEquals("5678 Main Street", service.getContact("3").getAddress(), "Address was updated successfully");
	}
	
	@Test
	@DisplayName("Deleting a Contact that is not found")
	void testFailDeleteContact()
	{
		//create new contact
		ContactService service = new ContactService();
		service.addContact("Jane", "Doe", "5555555555", "1234 Corner Street");
		
		//assert that the contact was not found and throws and error
		assertThrows(IllegalArgumentException.class, () -> service.deleteContact("100"));
	}
	
	@Test
	@DisplayName("Updating the First Name of a contact not found")
	void testFailUpdateFirstName()
	{
		//create new contact
		ContactService service = new ContactService();
		service.addContact("Jane", "Doe", "5555555555", "1234 Corner Street");
		
		//assert that the contact was not found and throws and error
		assertThrows(IllegalArgumentException.class, () -> service.updateFirstName("100", "Tom"));
	}
	
	@Test
	@DisplayName("Updating the Last Name of a contact not found")
	void testFailUpdateLatName()
	{
		//create new contact
		ContactService service = new ContactService();
		service.addContact("Jane", "Doe", "5555555555", "1234 Corner Street");
	
		//assert that the contact was not found and throws and error
		assertThrows(IllegalArgumentException.class, () -> service.updateLastName("100", "Smith"));
	}
	
	@Test
	@DisplayName("Updating the PhoneNumber of a contact not found")
	void testFailUpdatePhoneNumber()
	{
		//create new contact
		ContactService service = new ContactService();
		service.addContact("Jane", "Doe", "5555555555", "1234 Corner Street");
		
		//assert that the contact was not found and throws and error
		assertThrows(IllegalArgumentException.class, () -> service.updatePhoneNumber("100", "7777777777"));
	}
	
	@Test
	@DisplayName("Updating the Address of a contact not found")
	void testFailUpdateAddress()
	{
		//create new contact
		ContactService service = new ContactService();
		service.addContact("Jane", "Doe", "5555555555", "1234 Corner Street");
		
		//assert that the contact was not found and throws and error
		assertThrows(IllegalArgumentException.class, () -> service.updateAddress("100", "5678 Main Street"));
	}
}
