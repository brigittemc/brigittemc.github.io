package com.brigittemccoll.Contacts;

//============================================================================
//Name        : ContactService.java
//Author      : Brigitte McColl
//Description : Methods created to add a contact, delete a contact, get a contact,
//					and update the contacts first and last name, phone number, and address
//============================================================================


import java.util.HashMap;

public class ContactService {

	//creating the ID numbers
	int currentID = 0;
			
	//list to hold contacts
	public HashMap<String, Contact> contacts = new HashMap<String, Contact>();
	
	//add contact to list
	public void addContact(String firstName, String lastName, String phoneNumber, String address)
	{
		//setting key value
		String ID = Integer.toString(currentID);
		//create contact
		Contact contact = new Contact(firstName, lastName, phoneNumber, address);
		//add contact to list
		contacts.put(ID, contact);
		
		//increment the ID numbers
		++currentID;
	}
	
//	//Used to help find the Contact ID's to test
//	// Display the full list of contacts to the console for error checking.
//		public void displayContactList() {
//			for (int counter = 0; counter < contacts.size(); counter++) {
//				System.out.println("\t Contact ID: " + contacts.get(counter).getContactID());
//				System.out.println("\t First Name: " + contacts.get(counter).getFirstName());
//				System.out.println("\t Last Name: " + contacts.get(counter).getLastName());
//				System.out.println("\t Phone Number: " + contacts.get(counter).getPhoneNumber());
//				System.out.println("\t Address: " + contacts.get(counter).getAddress() + "\n");
//			}
//		}
//	
	//Getting Contact
		public Contact getContact(String contactID)
		{
			//searches for contact
			if(contacts.containsKey(contactID)) {
				//returns contact if found
				return contacts.get(contactID);
			}else {
				//returns null if not found
				return null;
			}
		}
		
	
	//Deleting Contact
	public void deleteContact(String contactID)
	{
		//searches for contact
		if(contacts.containsKey(contactID)) {
			//removes contact if found
			contacts.remove(contactID);
		}else {
			//throws error if not found
			throw new IllegalArgumentException("Contact not Found");
		}
	}
	
	public void updateFirstName(String contactID, String firstName)
	{
		
		//searches for contact
		if(contacts.containsKey(contactID)) {
			//updates the first name of the contact if found
			contacts.get(contactID).setFirstName(firstName);
		}else {
			//throws error if not found
			throw new IllegalArgumentException("Contact not Found");
		}
	}
	
	public void updateLastName(String contactID, String lastName)
	{
		//searches for contact
		if(contacts.containsKey(contactID)) {
			//updates the first name of the contact if found
			contacts.get(contactID).setLastName(lastName);
		}else {
			//throws error if not found
			throw new IllegalArgumentException("Contact not Found");
		}
	}
	
	public void updatePhoneNumber(String contactID, String phoneNumber)
	{
		//searches for contact
		if(contacts.containsKey(contactID)) {
			//updates the phone number of the contact if found
			contacts.get(contactID).setPhoneNumber(phoneNumber);
		}else {
			//throws error if not found
			throw new IllegalArgumentException("Contact not Found");
		}
	}
	
	public void updateAddress(String contactID, String address)
	{
		//searches for contact
		if(contacts.containsKey(contactID)) {
			//updates the address of the contact if found
			contacts.get(contactID).setAddress(address);
		}else {
			//throws error if not found
			throw new IllegalArgumentException("Contact not Found");
		}
	}
	
}
